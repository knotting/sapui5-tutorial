sap.ui.define([
	"ns/Ex06/test/unit/controller/View1.controller"
], function () {
	"use strict";
});