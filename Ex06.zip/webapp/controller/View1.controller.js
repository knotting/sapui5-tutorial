sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox"
], function (Controller, MessageBox) {
	"use strict";

	return Controller.extend("ns.Ex06.controller.View1", {
		onInit: function () {
			var data = {};
			data.firstName = "Goode";
			data.lastName = "Student";
			var model = new sap.ui.model.json.JSONModel(data);
			model.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			sap.ui.getCore().setModel(model);

			var selectionData = {
				"selection": "Please Select",
				"data": [{
					"text": "Alisha",
					"key": "Alisha"
				}, {
					"text": "Burt",
					"key": "Burt"
				}, {
					"text": "Candice",
					"key": "Candice"
				}, {
					"text": "Donald",
					"key": "Donald"
				}, {
					"text": "Erika",
					"key": "Erika"
				}, {
					"text": "Frank",
					"key": "Frank"
				}, {
					"text": "Goode",
					"key": "Goode"
				}]
			};
			var model2 = new sap.ui.model.json.JSONModel(selectionData);
			model2.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.byId("inpFirstName").setModel(model2, "selections");
			sap.ui.getCore().getModel().setData({
				firstName: this.byId("inpFirstName").getModel("selections").getProperty("/selection")
			}, true);

			// var uri = "/destinations/Northwinds/V3/northwind/northwind.svc/";
			// var model3 = new sap.ui.model.odata.ODataModel(uri, true);
			// this.byId("oDataTable").setModel(model3);
		},
		onBtnClick: function () {
			var firstName = this.byId("inpFirstName").getValue();
			var lastName = this.byId("inpLastName").getValue();
			var HTMLfirstName = sap.ui.getCore().byId("idView1--vHTML--inpFirstName").getValue();
			var HTMLlastName = sap.ui.getCore().byId("idView1--vHTML--inpLastName").getValue();
			var JSfirstName = sap.ui.getCore().byId("inpFirstName").getValue(); // This should really be idView1--vJS--inpFirstName
			var JSlastName = sap.ui.getCore().byId("inpLastName").getValue(); // This should really be idView1--vJS--inpLastName
			var JSONfirstName = sap.ui.getCore().byId("idView1--vJSON--inpFirstName").getValue();
			var JSONlastName = sap.ui.getCore().byId("idView1--vJSON--inpLastName").getValue();
			var message = "First Name: " + firstName + "\n" + "Last Name: " + lastName + "\n" +
				"HTML First: " + HTMLfirstName + "\n" + "HTML Last: " + HTMLlastName + "\n" +
				"JS First: " + JSfirstName + "\n" + "JS Last: " + JSlastName + "\n" +
				"JSON First: " + JSONfirstName + "\n" + "JSON Last: " + JSONlastName;
			MessageBox.show(message, {
				icon: MessageBox.Icon.SUCCESS, // default
				title: "Button Pressed",
				actions: MessageBox.Action.CLOSE,
				verticalScrolling: false,
				horizontalScrolling: false
			});
		}
	});
});