sap.ui.jsview("ns.Ex06.view.JSView", {
	getControllerName: function () {
		return "ns.Ex06.controller.JSView";
	},
	createContent: function (oController) {
		return new sap.m.Page({
			title: "Ex06 - JavaScript View",
			content: [
				new sap.m.Label({
					id: "lblFirstName",
					text: "First Name:"
				}),
				new sap.m.Input({
					id: "inpFirstName",
					value: ""
				}),
				new sap.m.Label({
					id: "lblLastName",
					text: "Last Name:"
				}),
				new sap.m.Input({
					id: "inpLastName",
					value: ""
				})
			]
		});
	}
});