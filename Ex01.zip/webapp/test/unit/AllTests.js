sap.ui.define([
	"ns/Ex01/test/unit/controller/View1.controller"
], function () {
	"use strict";
});