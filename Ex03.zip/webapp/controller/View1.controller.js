sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox"
], function (Controller, MessageBox) {
	"use strict";

	return Controller.extend("ns.Ex03.controller.View1", {
		onInit: function () {

		},
		onBtnClick: function () {
			var firstName = this.byId("inpFirstName").getValue();
			var lastName = this.byId("inpLastName").getValue();
			var message = "First Name: " + firstName + "\n" + "Last Name: " + lastName;
			MessageBox.show(message, {
				icon: MessageBox.Icon.SUCCESS,
				title: "Button Pressed",
				actions: MessageBox.Action.CLOSE
			});

			// var firstName = this.byId("inpFirstName").getValue();
			// var lastName = this.byId("inpLastName").getValue();
			// var HTMLfirstName = sap.ui.getCore().byId("idView1--vHTML--inpFirstName").getValue();
			// var HTMLlastName = sap.ui.getCore().byId("idView1--vHTML--inpLastName").getValue();
			// var JSfirstName = sap.ui.getCore().byId("inpFirstName").getValue(); // This should really be idView1--vJS--inpFirstName
			// var JSlastName = sap.ui.getCore().byId("inpLastName").getValue(); // This should really be idView1--vJS--inpLastName
			// var JSONfirstName = sap.ui.getCore().byId("idView1--vJSON--inpFirstName").getValue();
			// var JSONlastName = sap.ui.getCore().byId("idView1--vJSON--inpLastName").getValue();
			// var message = "First Name: " + firstName + "\n" + "Last Name: " + lastName + "\n" +
			// 	"HTML First: " + HTMLfirstName + "\n" + "HTML Last: " + HTMLlastName + "\n" +
			// 	"JS First: " + JSfirstName + "\n" + "JS Last: " + JSlastName + "\n" +
			// 	"JSON First: " + JSONfirstName + "\n" + "JSON Last: " + JSONlastName;
			// MessageBox.show(message, {
			// 	icon: MessageBox.Icon.SUCCESS, // default
			// 	title: "Button Pressed",
			// 	actions: MessageBox.Action.CLOSE,
			// 	verticalScrolling: false,
			// 	horizontalScrolling: false
			// });
		}
	});
});