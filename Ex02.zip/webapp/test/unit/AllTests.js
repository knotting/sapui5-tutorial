sap.ui.define([
	"ns/Ex02/test/unit/controller/View1.controller"
], function () {
	"use strict";
});