sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox"
], function (Controller, MessageBox) {
	"use strict";

	return Controller.extend("ns.Ex02.controller.View1", {
		onInit: function () {

		},
		onBtnClick: function () {
			var firstName = this.byId("inpFirstName").getValue();
			var lastName = this.byId("inpLastName").getValue();
			var message = "First Name: " + firstName + "\n" + "Last Name: " + lastName;
			MessageBox.show(message, {
				icon: MessageBox.Icon.SUCCESS,
				title: "Button Pressed",
				actions: MessageBox.Action.CLOSE
			});
		}
	});
});