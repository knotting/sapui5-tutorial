sap.ui.define([
	"ns/Ex04/test/unit/controller/View1.controller"
], function () {
	"use strict";
});